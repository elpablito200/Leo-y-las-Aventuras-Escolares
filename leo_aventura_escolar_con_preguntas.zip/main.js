
window.onload = () => {
  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d");
  const startScreen = document.getElementById("start-screen");
  const startButton = document.getElementById("start-button");
  const bgMusic = document.getElementById("bg-music");

  const leo = new Image();
  leo.src = "assets/leo.png";

  let x = 50;
  let y = 300;
  let vy = 0;
  let gravity = 0.5;
  let jumping = false;
  let speed = 5;
  let showQuestion = false;
  let currentQuestion = 0;
  let questionAnswered = false;

  const questions = [
    {
      question: "¿Cuál es una palabra aguda?",
      options: ["Árbol", "Camión", "Lápiz"],
      answer: 1
    },
    {
      question: "¿Cuánto es 8 x 7?",
      options: ["56", "64", "42"],
      answer: 0
    }
  ];

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#87CEEB";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(leo, x, y, 60, 60);

    if (showQuestion && questions[currentQuestion]) {
      const q = questions[currentQuestion];
      ctx.fillStyle = "#000";
      ctx.fillRect(100, 50, 600, 200);
      ctx.fillStyle = "#fff";
      ctx.font = "18px Arial";
      ctx.fillText(q.question, 120, 80);
      ctx.fillText("A: " + q.options[0], 120, 120);
      ctx.fillText("B: " + q.options[1], 120, 160);
      ctx.fillText("C: " + q.options[2], 120, 200);
    }
  }

  function update() {
    vy += gravity;
    y += vy;
    if (y >= 300) {
      y = 300;
      vy = 0;
      jumping = false;
    }
  }

  function gameLoop() {
    update();
    draw();
    requestAnimationFrame(gameLoop);
  }

  document.addEventListener("keydown", (e) => {
    if (e.key === "d") x += speed;
    if (e.code === "Space" && !jumping) {
      vy = -10;
      jumping = true;
    }
    if (showQuestion && !questionAnswered) {
      let selected = -1;
      if (e.key === "a") selected = 0;
      if (e.key === "b") selected = 1;
      if (e.key === "c") selected = 2;

      if (selected !== -1) {
        if (selected === questions[currentQuestion].answer) {
          alert("¡Bien hecho!");
        } else {
          alert("¡Intenta de nuevo!");
        }
        questionAnswered = true;
        showQuestion = false;
        currentQuestion++;
      }
    }
  });

  startButton.onclick = () => {
    startScreen.style.display = "none";
    bgMusic.volume = 0.5;
    gameLoop();

    setTimeout(() => {
      showQuestion = true;
      questionAnswered = false;
    }, 5000); // aparece una pregunta después de 5 segundos
  };
};
